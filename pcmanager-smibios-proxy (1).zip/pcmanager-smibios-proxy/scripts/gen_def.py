import os, argparse, pefile

def is_forwarder(pe, rva):
    d = pe.OPTIONAL_HEADER.DATA_DIRECTORY[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_EXPORT']]
    start, end = d.VirtualAddress, d.VirtualAddress + d.Size
    return start <= rva < end

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arch", choices=["x64","x86"], default="x64")
    ap.add_argument("--out", default="src/version.def")
    args = ap.parse_args()

    sysdir = os.path.join(os.environ["WINDIR"], "System32" if args.arch=="x64" else "SysWOW64")
    path = os.path.join(sysdir, "version.dll")
    pe = pefile.PE(path, fast_load=True)
    pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_EXPORT']])

    lines = ["LIBRARY version", "EXPORTS"]
    for exp in sorted(pe.DIRECTORY_ENTRY_EXPORT.symbols, key=lambda e: e.ordinal):
        if not exp.name:
            continue
        name = exp.name.decode("ascii")
        line = f"{name} @ {exp.ordinal}"
        if is_forwarder(pe, exp.address):
            fwd = pe.get_string_at_rva(exp.address).decode("ascii")
            line += f"     ; forwarded: {fwd}"
        lines.append(line)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="ascii", newline="\n") as f:
        f.write("\n".join(lines))
    print(f"Wrote {args.out}")

if __name__ == "__main__":
    main()
