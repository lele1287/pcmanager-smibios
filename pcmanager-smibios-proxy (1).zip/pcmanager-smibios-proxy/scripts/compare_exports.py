import pefile, sys, os

def read_exports(path):
    pe = pefile.PE(path, fast_load=True)
    pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_EXPORT']])
    out = []
    for e in pe.DIRECTORY_ENTRY_EXPORT.symbols:
        if e.name:
            out.append((e.ordinal, e.name.decode('ascii')))
    return sorted(out, key=lambda x: x[0])

if __name__ == "__main__":
    our = sys.argv[1]
    arch = sys.argv[2]
    sysdir = os.path.join(os.environ["WINDIR"], "System32" if arch=="x64" else "SysWOW64")
    sysdll = os.path.join(sysdir, "version.dll")

    ours = read_exports(our)
    sysv = read_exports(sysdll)

    if ours != sysv:
        print("Mismatch between our version.dll and system version.dll exports!")
        so = set(ours); ss = set(sysv)
        print("Missing in ours:", sorted(ss - so))
        print("Extra in ours  :", sorted(so - ss))
        sys.exit(1)
    print("Exports match (ordinal+name).")
