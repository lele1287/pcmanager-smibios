#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <vector>
#include <cstdint>
#include <cstring>

#pragma pack(push,1)
struct RawSMBIOSData { BYTE Used20CallingMethod, SMBIOSMajorVersion, SMBIOSMinorVersion, DmiRevision; DWORD Length; };
struct SMBIOS_HEADER { BYTE Type; BYTE Length; WORD Handle; };
#pragma pack(pop)

static DWORD FCC(const char* s){ return (DWORD)(uint8_t)s[0] | ((DWORD)(uint8_t)s[1]<<8) | ((DWORD)(uint8_t)s[2]<<16) | ((DWORD)(uint8_t)s[3]<<24); }
static const char* GetStr(const BYTE* start, BYTE idx, BYTE len){ if(!idx) return ""; const char* p=(const char*)start+len; for(BYTE i=1;i<idx;++i) p+=strlen(p)+1; return p; }

int wmain(){
    // 强制加载当前目录下的 version.dll（代理会在首次调用时安装 Hook）
    LoadLibraryW(L"version.dll");

    UINT need = GetSystemFirmwareTable(FCC("RSMB"), 0, nullptr, 0);
    if (!need){ wprintf(L"[!] Query size failed: %lu\n", GetLastError()); return 1; }
    std::vector<BYTE> buf(need);
    UINT got = GetSystemFirmwareTable(FCC("RSMB"), 0, buf.data(), need);
    if (got != need){ wprintf(L"[!] Read failed.\n"); return 2; }

    auto* hdr = (const RawSMBIOSData*)buf.data();
    const BYTE* cur = buf.data()+sizeof(RawSMBIOSData);
    const BYTE* end = cur + hdr->Length;

    while (cur + sizeof(SMBIOS_HEADER) < end){
        auto* h = (const SMBIOS_HEADER*)cur; const BYTE* n = cur + h->Length;
        while (n+1 < end && (n[0]!=0 || n[1]!=0)) ++n; // 找 00 00
        if (h->Type == 1){
            struct T1 { SMBIOS_HEADER H; BYTE Man,Prod,Ver,Sn,Uuid[16],Wake,Sku,Fam; };
            auto* t1 = (const T1*)cur;
            const char* man = GetStr(cur, t1->Man,  t1->H.Length);
            const char* pro = GetStr(cur, t1->Prod, t1->H.Length);
            const char* ver = GetStr(cur, t1->Ver,  t1->H.Length);
            const char* sn  = GetStr(cur, t1->Sn,   t1->H.Length);
            const char* sku = GetStr(cur, t1->Sku,  t1->H.Length);
            const char* fam = GetStr(cur, t1->Fam,  t1->H.Length);
            printf("Manufacturer : %s\n", man);
            printf("Product Name : %s\n", pro);
            printf("Version      : %s\n", ver);
            printf("Serial Number: %s\n", sn);
            printf("Wakeup Type  : 0x%02X\n", t1->Wake);
            printf("SKU Number   : %s\n", sku);
            printf("Family       : %s\n", fam);
            return 0;
        }
        cur = n + 2;
    }
    wprintf(L"[!] Type 1 not found.\n");
    return 3;
}
