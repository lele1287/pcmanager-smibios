#include "smbios_spoof.hpp"
#include <array>
#include <mutex>
#include <cstring>
#include <cctype>
#include <string>

static constexpr const char* kManufacturer  = "HUAWEI";
static constexpr const char* kProductName   = "FLMH-XX";
static constexpr const char* kVersion       = "M1010";
static constexpr const char* kSerial        = "2VBBB2481480888";
static constexpr const char* kSku           = "C233";
static constexpr const char* kFamily        = "MateBook";
static constexpr const char* kUuidText      = "20240816-105F-AD36-7653-105FAD367657";

static uint8_t hex_val(char c){
    if (c>='0' && c<='9') return (uint8_t)(c-'0');
    c = (char)std::toupper((unsigned char)c);
    if (c>='A' && c<='F') return (uint8_t)(c-'A'+10);
    return 0;
}

static std::array<uint8_t,16> ParseUuid(const std::string& s) {
    std::string hex; hex.reserve(32);
    for (unsigned char c : s) if (std::isxdigit(c)) hex.push_back((char)std::toupper(c));
    std::array<uint8_t,16> out{};
    for (size_t i=0; i+1<hex.size() && (i/2)<out.size(); i+=2) {
        out[i/2] = (hex_val(hex[i])<<4) | hex_val(hex[i+1]);
    }
    return out;
}

const std::vector<uint8_t>& BuildSpoofedRSMB() {
    static std::vector<uint8_t> cached;
    static std::once_flag once;
    std::call_once(once, []{
        struct TYPE1_FIXED {
            SMBIOS_HEADER H;
            uint8_t  Manufacturer;
            uint8_t  ProductName;
            uint8_t  Version;
            uint8_t  Serial;
            uint8_t  UUID[16];
            uint8_t  WakeupType; // 0x06 Power Switch
            uint8_t  SKUNumber;
            uint8_t  Family;
        } f{};
        f.H.Type=1; f.H.Length=0x1B; f.H.Handle=0x0100;
        f.Manufacturer=1; f.ProductName=2; f.Version=3; f.Serial=4;
        auto uuid=ParseUuid(kUuidText); std::memcpy(f.UUID, uuid.data(), uuid.size());
        f.WakeupType=0x06; f.SKUNumber=5; f.Family=6;

        std::vector<uint8_t> t1(sizeof(TYPE1_FIXED));
        std::memcpy(t1.data(), &f, sizeof(TYPE1_FIXED));
        auto append_sz = [&](const char* s){ size_t n=std::strlen(s); t1.insert(t1.end(), (const uint8_t*)s, (const uint8_t*)s+n); t1.push_back(0); };
        append_sz(kManufacturer); append_sz(kProductName); append_sz(kVersion); append_sz(kSerial); append_sz(kSku); append_sz(kFamily);
        t1.push_back(0); // 双 00 终止

        RawSMBIOSData hdr{}; hdr.SMBIOSMajorVersion=3; hdr.SMBIOSMinorVersion=4; hdr.Length=(uint32_t)t1.size();

        cached.resize(sizeof(RawSMBIOSData)+t1.size());
        std::memcpy(cached.data(), &hdr, sizeof(RawSMBIOSData));
        std::memcpy(cached.data()+sizeof(RawSMBIOSData), t1.data(), t1.size());
    });
    return cached;
}
