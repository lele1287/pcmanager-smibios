#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <MinHook.h>
#include <mutex>
#include <string>
#include "smbios_spoof.hpp"

namespace {
    HMODULE g_realVersion = nullptr;
    INIT_ONCE g_onceReal  = INIT_ONCE_STATIC_INIT;

    FARPROC ResolveReal(const char* name) {
        auto init = PINIT_ONCE, PVOID, PVOID*->BOOL{
            wchar_t sysdir[MAX_PATH]={0}; GetSystemDirectoryW(sysdir, MAX_PATH);
            std::wstring p = std::wstring(sysdir)+L"\\version.dll";
            g_realVersion = LoadLibraryW(p.c_str());
            return g_realVersion?TRUE:FALSE;
        };
        PVOID ctx=nullptr; InitOnceExecuteOnce(&g_onceReal, init, nullptr, &ctx);
        return g_realVersion ? GetProcAddress(g_realVersion, name) : nullptr;
    }
    FARPROC ResolveKernel32(const char* name) {
        static HMODULE k32 = GetModuleHandleW(L"KERNEL32.DLL");
        return k32 ? GetProcAddress(k32, name) : nullptr;
    }
    constexpr DWORD FCC4(char a,char b,char c,char d){
        return (DWORD)(uint8_t)a | ((DWORD)(uint8_t)b<<8) | ((DWORD)(uint8_t)c<<16) | ((DWORD)(uint8_t)d<<24);
    }
}

using PFN_GetSFT = UINT (WINAPI*)(DWORD,DWORD,PVOID,DWORD);
static PFN_GetSFT  s_OrigGetSFT = nullptr;
static INIT_ONCE   g_onceHook   = INIT_ONCE_STATIC_INIT;

static UINT WINAPI Detour_GetSystemFirmwareTable(DWORD sig, DWORD id, PVOID buf, DWORD size) {
    constexpr DWORD RSMB = FCC4('R','S','M','B');
    if (sig==RSMB && id==0) {
        auto& bytes = BuildSpoofedRSMB();
        UINT need = (UINT)bytes.size();
        if (!buf || size < need) return need; // 规范：返回所需大小
        std::memcpy(buf, bytes.data(), need);
        return need;
    }
    return s_OrigGetSFT ? s_OrigGetSFT(sig,id,buf,size) : 0;
}

static BOOL EnsureHookInstalled() {
    auto init = PINIT_ONCE, PVOID, PVOID*->BOOL {
        if (MH_Initialize()!=MH_OK) return FALSE;
        auto pfn = (PFN_GetSFT)GetProcAddress(GetModuleHandleW(L"KERNEL32.DLL"), "GetSystemFirmwareTable");
        if (!pfn) return FALSE;
        if (MH_CreateHook((LPVOID)pfn, (LPVOID)&Detour_GetSystemFirmwareTable, (LPVOID*)&s_OrigGetSFT)!=MH_OK) return FALSE;
        if (MH_EnableHook((LPVOID)pfn)!=MH_OK) return FALSE;
        return TRUE;
    };
    PVOID ctx=nullptr; return InitOnceExecuteOnce(&g_onceHook, init, nullptr, &ctx);
}

extern "C" __declspec(dllexport) BOOL WINAPI GetFileVersionInfoW(LPCWSTR f, DWORD h, DWORD l, LPVOID d){
    (void)EnsureHookInstalled(); using PFN=BOOL (WINAPI*)(LPCWSTR,DWORD,DWORD,LPVOID);
    static PFN p=(PFN)ResolveReal("GetFileVersionInfoW"); return p? p(f,h,l,d):FALSE;
}
extern "C" __declspec(dllexport) BOOL WINAPI GetFileVersionInfoA(LPCSTR f, DWORD h, DWORD l, LPVOID d){
    (void)EnsureHookInstalled(); using PFN=BOOL (WINAPI*)(LPCSTR,DWORD,DWORD,LPVOID);
    static PFN p=(PFN)ResolveReal("GetFileVersionInfoA"); return p? p(f,h,l,d):FALSE;
}
extern "C" __declspec(dllexport) DWORD WINAPI GetFileVersionInfoSizeW(LPCWSTR f, LPDWORD h){
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(LPCWSTR,LPDWORD);
    static PFN p=(PFN)ResolveReal("GetFileVersionInfoSizeW"); return p? p(f,h):0;
}
extern "C" __declspec(dllexport) DWORD WINAPI GetFileVersionInfoSizeA(LPCSTR f, LPDWORD h){
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(LPCSTR,LPDWORD);
    static PFN p=(PFN)ResolveReal("GetFileVersionInfoSizeA"); return p? p(f,h):0;
}
extern "C" __declspec(dllexport) BOOL WINAPI GetFileVersionInfoExW(DWORD fl,LPCWSTR f,DWORD h,DWORD l,LPVOID d){
    (void)EnsureHookInstalled(); using PFN=BOOL (WINAPI*)(DWORD,LPCWSTR,DWORD,DWORD,LPVOID);
    static PFN p=(PFN)ResolveReal("GetFileVersionInfoExW"); return p? p(fl,f,h,l,d):FALSE;
}
extern "C" __declspec(dllexport) BOOL WINAPI GetFileVersionInfoExA(DWORD fl,LPCSTR f,DWORD h,DWORD l,LPVOID d){
    (void)EnsureHookInstalled(); using PFN=BOOL (WINAPI*)(DWORD,LPCSTR,DWORD,DWORD,LPVOID);
    static PFN p=(PFN)ResolveReal("GetFileVersionInfoExA"); return p? p(fl,f,h,l,d):FALSE;
}
extern "C" __declspec(dllexport) DWORD WINAPI GetFileVersionInfoSizeExW(DWORD fl,LPCWSTR f,LPDWORD h){
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(DWORD,LPCWSTR,LPDWORD);
    static PFN p=(PFN)ResolveReal("GetFileVersionInfoSizeExW"); return p? p(fl,f,h):0;
}
extern "C" __declspec(dllexport) DWORD WINAPI GetFileVersionInfoSizeExA(DWORD fl,LPCSTR f,LPDWORD h){
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(DWORD,LPCSTR,LPDWORD);
    static PFN p=(PFN)ResolveReal("GetFileVersionInfoSizeExA"); return p? p(fl,f,h):0;
}
extern "C" __declspec(dllexport) BOOL WINAPI VerQueryValueW(LPCVOID b,LPCWSTR s,LPVOID* o,PUINT u){
    (void)EnsureHookInstalled(); using PFN=BOOL (WINAPI*)(LPCVOID,LPCWSTR,LPVOID*,PUINT);
    static PFN p=(PFN)ResolveReal("VerQueryValueW"); return p? p(b,s,o,u):FALSE;
}
extern "C" __declspec(dllexport) BOOL WINAPI VerQueryValueA(LPCVOID b,LPCSTR s,LPVOID* o,PUINT u){
    (void)EnsureHookInstalled(); using PFN=BOOL (WINAPI*)(LPCVOID,LPCSTR,LPVOID*,PUINT);
    static PFN p=(PFN)ResolveReal("VerQueryValueA"); return p? p(b,s,o,u):FALSE;
}
extern "C" __declspec(dllexport) DWORD WINAPI VerFindFileW(DWORD fl,LPCWSTR fn,LPCWSTR win,LPCWSTR app,LPWSTR cur,PUINT pc,LPWSTR dst,PUINT pd){
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(DWORD,LPCWSTR,LPCWSTR,LPCWSTR,LPWSTR,PUINT,LPWSTR,PUINT);
    static PFN p=(PFN)ResolveReal("VerFindFileW"); return p? p(fl,fn,win,app,cur,pc,dst,pd):0;
}
extern "C" __declspec(dllexport) DWORD WINAPI VerFindFileA(DWORD fl,LPCSTR fn,LPCSTR win,LPCSTR app,LPSTR cur,PUINT pc,LPSTR dst,PUINT pd){
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(DWORD,LPCSTR,LPCSTR,LPCSTR,LPSTR,PUINT,LPSTR,PUINT);
    static PFN p=(PFN)ResolveReal("VerFindFileA"); return p? p(fl,fn,win,app,cur,pc,dst,pd):0;
}
extern "C" __declspec(dllexport) DWORD WINAPI VerInstallFileW(DWORD fl,LPCWSTR s,LPCWSTR d,LPCWSTR sd,LPCWSTR dd,LPCWSTR cd,LPWSTR tmp,PUINT plen){
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(DWORD,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,LPWSTR,PUINT);
    static PFN p=(PFN)ResolveReal("VerInstallFileW"); return p? p(fl,s,d,sd,dd,cd,tmp,plen):0;
}
extern "C" __declspec(dllexport) DWORD WINAPI VerInstallFileA(DWORD fl,LPCSTR s,LPCSTR d,LPCSTR sd,LPCSTR dd,LPCSTR cd,LPSTR tmp,PUINT plen){
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(DWORD,LPCSTR,LPCSTR,LPCSTR,LPCSTR,LPCSTR,LPSTR,PUINT);
    static PFN p=(PFN)ResolveReal("VerInstallFileA"); return p? p(fl,s,d,sd,dd,cd,tmp,plen):0;
}
extern "C" __declspec(dllexport) DWORD WINAPI VerLanguageNameW(DWORD wLang, LPWSTR szLang, DWORD cchLang) {
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(DWORD,LPWSTR,DWORD);
    static PFN p=(PFN)ResolveKernel32("VerLanguageNameW"); return p? p(wLang,szLang,cchLang):0;
}
extern "C" __declspec(dllexport) DWORD WINAPI VerLanguageNameA(DWORD wLang, LPSTR szLang, DWORD cchLang) {
    (void)EnsureHookInstalled(); using PFN=DWORD (WINAPI*)(DWORD,LPSTR,DWORD);
    static PFN p=(PFN)ResolveKernel32("VerLanguageNameA"); return p? p(wLang,szLang,cchLang):0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID) {
    if (r==DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(h);
    return TRUE;
}
