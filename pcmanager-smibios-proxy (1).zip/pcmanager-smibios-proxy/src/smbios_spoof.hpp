#pragma once
#include <vector>
#include <cstdint>

#pragma pack(push, 1)
struct RawSMBIOSData {
    uint8_t  Used20CallingMethod;
    uint8_t  SMBIOSMajorVersion;
    uint8_t  SMBIOSMinorVersion;
    uint8_t  DmiRevision;
    uint32_t Length;
};
struct SMBIOS_HEADER { uint8_t Type; uint8_t Length; uint16_t Handle; };
#pragma pack(pop)

const std::vector<uint8_t>& BuildSpoofedRSMB();
